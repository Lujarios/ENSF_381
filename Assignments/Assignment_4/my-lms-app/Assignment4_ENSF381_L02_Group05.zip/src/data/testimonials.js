const testimonials = [
	{
		studentName: "Alice Johnson",
		courseName: "Web Development",
		review: "Excellent course structure!",
		rating: 5
	},
	// Add 3 more testimonials... 
	{
		studentName: "Bob Smith",
		courseName: "Data Science",
		review: "Great course!",
		rating: 4
	},
	{
		studentName: "Charlie Brown",
		courseName: "Cloud Computing",
		review: "Not bad.",
		rating: 2
	},
	{
		studentName: "Diana Prince",
		courseName: "Cybersecurity",
		review: "Could be better.",
		rating: 3
	}
];
export default testimonials;
function Footer() {
	return (
		<footer>
			<p>&copy; 2025 LMS. All rights reserved.</p>
		</footer>
	);
}
export default Footer;